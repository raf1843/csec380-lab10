**Please do not post bugs or ask questions**

**For help and support you can use our [Discord server](https://t.libren.ms/discord) or our [community site](https://community.librenms.org/c/help).**

To create a new device request please use this link: https://github.com/librenms/librenms/issues/new?template=New-Device.md
