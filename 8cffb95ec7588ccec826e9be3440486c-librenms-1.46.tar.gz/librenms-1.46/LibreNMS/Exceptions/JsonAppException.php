<?php

namespace LibreNMS\Exceptions;

class JsonAppException extends \Exception
{

}
