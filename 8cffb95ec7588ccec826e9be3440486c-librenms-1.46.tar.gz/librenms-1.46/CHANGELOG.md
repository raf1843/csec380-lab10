The changelog can be found at our [docs](https://docs.librenms.org/#General/Changelog/) site.
